import React from "react";
import ContactForm from "../Components/ContactForm";
import Footer from "../Components/Footer";
import Heroimg2 from "../Components/Heroimg2";
import Navbar from "../Components/Navbar";
const Contact = () => {
  return (
    <div>
      <Navbar />
      <Heroimg2 heading="Contact." text="Let's Discuss More." />
      <ContactForm />
      <Footer />
    </div>
  );
};

export default Contact;
