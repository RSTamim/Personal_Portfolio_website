import React from "react";
import AboutContent from "../Components/AboutContent";
import ContactForm from "../Components/ContactForm";
import Footer from "../Components/Footer";
import Hero from "../Components/Hero";
import Navbar from "../Components/Navbar";
import Work from "../Components/Work";

const Home = () => {
  return (
    <div>
      <Navbar />
      <Hero />
      <AboutContent />
      <Work />
      <ContactForm />
      <Footer />
    </div>
  );
};

export default Home;
