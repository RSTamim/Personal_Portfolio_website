import React from "react";
import Footer from "../Components/Footer";
import Heroimg2 from "../Components/Heroimg2";
import Navbar from "../Components/Navbar";
import PricingCards from "../Components/PricingCards";
import Work from "../Components/Work";
const Project = () => {
  return (
    <div>
      <Navbar />
      <Heroimg2 heading="PROJECTS." text="Some of me recent works." />
      <Work />
      <PricingCards />
      <Footer />
    </div>
  );
};

export default Project;
