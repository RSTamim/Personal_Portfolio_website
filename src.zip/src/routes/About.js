import React from "react";
import Footer from "../Components/Footer";
import Heroimg2 from "../Components/Heroimg2";
import Navbar from "../Components/Navbar";
import AboutContent from "../Components/AboutContent";
import ContactForm from "../Components/ContactForm";
const About = () => {
  return (
    <div>
      <Navbar />
      <Heroimg2 heading="About." text="I'm a friendly React Developer" />
      <AboutContent />
      <ContactForm />
      <Footer />
    </div>
  );
};

export default About;
