import React from "react";
import {
  FaFacebook,
  FaHome,
  FaLinkedin,
  FaMailBulk,
  FaPhone,
  FaTwitter,
} from "react-icons/fa";
import "./Footer.css";
const Footer = () => {
  return (
    <div className="footer">
      <div className="footer-container">
        <div className="left-f">
          <div className="location">
            <FaHome
              size={25}
              style={{ color: "rgb(248, 217, 15)", marginRight: "2rem" }}
            />
            <div>
              <p>103/A, Road-6 Housing Society</p>
              <p>Mohammodpur, Bangladesh</p>
            </div>
          </div>
          <div className="phone">
            <FaPhone
              size={25}
              style={{ color: "rgb(248, 217, 15)", marginRight: "2rem" }}
            />
            <div>
              <p>01300306993</p>
            </div>
          </div>
          <div className="email">
            <FaMailBulk
              size={25}
              style={{ color: "rgb(248, 217, 15)", marginRight: "2rem" }}
            />
            <div>
              <p>teckpark@gmail.com</p>
            </div>
          </div>
        </div>
        <div className="right-f">
          <h4>About the company</h4>
          <p>
            This is Md. Tamim Hasan. CEO & Founder of TechPark. I enjoy
            discussing new project and design challenge
          </p>
          <div className="social">
            <FaFacebook
              size={30}
              style={{ color: "rgb(248, 217, 15)", marginRight: "1rem" }}
            />
            <FaTwitter
              size={30}
              style={{ color: "rgb(248, 217, 15)", marginRight: "1rem" }}
            />
            <FaLinkedin
              size={30}
              style={{ color: "rgb(248, 217, 15)", marginRight: "1rem" }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Footer;
