import pro1 from "../assets/project1.png";
import pro2 from "../assets/project2.png";
import pro3 from "../assets/project3.png";
const ProjectCaedData = [
  {
    imgsrc: pro1,
    title: "Ecommerce Website Design",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },

  {
    imgsrc: pro3,
    title: "WordPress Website Design",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },

  {
    imgsrc: pro2,
    title: "Landing Page Design & Development",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },
  {
    imgsrc: pro1,
    title: "Ecommerce Website Design",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },

  {
    imgsrc: pro3,
    title: "WordPress Website Design",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },

  {
    imgsrc: pro2,
    title: "Landing Page Design & Development",
    text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
    view: "https://github.com/RSTamim",
  },
];

export default ProjectCaedData;
